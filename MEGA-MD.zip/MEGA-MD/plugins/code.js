const { authCodes } = require('../lib/server');

module.exports = {
    command: 'code',
    category: 'main',
    description: 'Get dashboard login code',
    usage: '.code',
    async handler(sock, m, args) {
        const number = m.sender.split('@')[0];
        const code = Math.floor(100000 + Math.random() * 900000).toString();
        
        authCodes.set(number, code);
        
        // Remove code after 5 minutes
        setTimeout(() => authCodes.delete(number), 5 * 60 * 1000);
        
        await sock.sendMessage(m.chat, {
            text: `🔐 *DASHBOARD LOGIN CODE*\n\nNumber: ${number}\nCode: *${code}*\n\nUse this code to login at the dashboard. Valid for 5 minutes.`
        }, { quoted: m });
    }
};
