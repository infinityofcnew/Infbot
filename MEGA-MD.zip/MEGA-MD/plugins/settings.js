const isOwnerOrSudo = require('../lib/isOwner');
const store = require('../lib/lightweight_store');
const { cleanJid } = require('../lib/isOwner');

module.exports = {
    command: 'settings',
    aliases: ['config', 'setting'],
    category: 'owner',
    description: 'Show bot settings and per-group configurations',
    usage: '.settings',
    async handler(sock, message, args, context = {}) {
        const chatId = context.chatId || message.key.remoteJid;

        try {
            const senderId = message.key.participant || message.key.remoteJid;
            const isOwner = await isOwnerOrSudo(senderId, sock, chatId);
            const isMe = message.key.fromMe;

            const action = args[0]?.toLowerCase();
            if (action && (isMe || isOwner)) {
                if (action === 'antidelete') {
                    const current = await store.getSetting('global', 'antidelete');
                    await store.saveSetting('global', 'antidelete', !current);
                    return await sock.sendMessage(chatId, { text: `✅ *Anti Delete* turned ${!current ? 'ON' : 'OFF'}` }, { quoted: message });
                }
                if (action === 'antiviewonce') {
                    const current = await store.getSetting('global', 'antiviewonce');
                    await store.saveSetting('global', 'antiviewonce', !current);
                    return await sock.sendMessage(chatId, { text: `✅ *Anti ViewOnce* turned ${!current ? 'ON' : 'OFF'}` }, { quoted: message });
                }
                if (action === 'antiviewonce_mode') {
                    const modes = ['owner', 'chat', 'warn'];
                    const current = (await store.getSetting('global', 'antiviewonce_mode')) || 'owner';
                    const nextMode = modes[(modes.indexOf(current) + 1) % modes.length];
                    await store.saveSetting('global', 'antiviewonce_mode', nextMode);
                    return await sock.sendMessage(chatId, { text: `✅ *Anti ViewOnce Mode* set to: *${nextMode.toUpperCase()}*` }, { quoted: message });
                }
            }

            if (!isMe && !isOwner) {
                return await sock.sendMessage(chatId, { 
                    text: '❌ *Access Denied:* Only Owner/Sudo can view settings.' 
                }, { quoted: message });
            }
            
            const isGroup = chatId.endsWith('@g.us');

            const botMode = await store.getBotMode();
            
            const allSettings = await store.getAllSettings('global');
            const autoStatus = allSettings.autoStatus || { enabled: false };
            const autoread = allSettings.autoread || { enabled: false };
            const autotyping = allSettings.autotyping || { enabled: false };
            const pmblocker = allSettings.pmblocker || { enabled: false };
            const anticall = allSettings.anticall || { enabled: false };
            const autoReaction = allSettings.autoReaction || false;
            const antidelete = allSettings.antidelete || false;
            const antiviewonce = allSettings.antiviewonce || false;

            const getSt = (val) => val ? '✅' : '❌';

            let menuText = `╭━〔 *INFINITY SETTINGS* 〕━┈\n┃\n`;
            menuText += `┃ 👤 *User:* @${cleanJid(senderId)}\n`;
            menuText += `┃ 🤖 *Mode:* ${botMode.toUpperCase()}\n`;
            menuText += `┃\n┣━〔 *GLOBAL CONFIG* 〕━┈\n`;
            menuText += `┃ ${getSt(autoStatus?.enabled)} *Auto Status*\n`;
            menuText += `┃ ${getSt(autoread?.enabled)} *Auto Read*\n`;
            menuText += `┃ ${getSt(autotyping?.enabled)} *Auto Typing*\n`;
            menuText += `┃ ${getSt(pmblocker?.enabled)} *PM Blocker*\n`;
            menuText += `┃ ${getSt(anticall?.enabled)} *Anti Call*\n`;
            menuText += `┃ ${getSt(autoReaction)} *Auto Reaction*\n`;
            menuText += `┃ ${getSt(antidelete)} *Anti Delete*\n`;
            menuText += `┃ ${getSt(antiviewonce)} *Anti ViewOnce*\n`;
            menuText += `┃\n`;

            if (isGroup) {
                const groupSettings = await store.getAllSettings(chatId);
                
                const groupAntilink = groupSettings.antilink || { enabled: false };
                const groupBadword = groupSettings.antibadword || { enabled: false };
                const groupAntitag = groupSettings.antitag || { enabled: false };
                const groupChatbot = groupSettings.chatbot || false;
                const groupWelcome = groupSettings.welcome || false;
                const groupGoodbye = groupSettings.goodbye || false;

                menuText += `┣━〔 *GROUP CONFIG* 〕━┈\n`;
                menuText += `┃ ${getSt(groupAntilink.enabled)} *Antilink*\n`;
                menuText += `┃ ${getSt(groupBadword.enabled)} *Antibadword*\n`;
                menuText += `┃ ${getSt(groupAntitag.enabled)} *Antitag*\n`;
                menuText += `┃ ${getSt(groupChatbot)} *Chatbot*\n`;
                menuText += `┃ ${getSt(groupWelcome)} *Welcome*\n`;
                menuText += `┃ ${getSt(groupGoodbye)} *Goodbye*\n`;
            } else {
                menuText += `┃ 💡 *Note:* _Use in group for group configs._\n`;
            }

            menuText += `┃\n╰━━━━━━━━━━━━━━━━┈`;

            await sock.sendMessage(chatId, { 
                text: menuText,
                mentions: [senderId],
                contextInfo: {
                    externalAdReply: {
                        title: "SYSTEM SETTINGS PANEL",
                        body: "Configuration Status",
                        thumbnailUrl: "https://github.com/GlobalTechInfo.png",
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: message });

        } catch (error) {
            console.error('Settings Command Error:', error);
            await sock.sendMessage(chatId, { 
                text: '❌ Error: Failed to load settings.' 
            }, { quoted: message });
        }
    }
};
