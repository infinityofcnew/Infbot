const axios = require('axios');

module.exports = {
  command: 'ai',
  aliases: ['chat', 'gpt'],
  category: 'ai',
  description: 'Chat with AI Assistant',
  usage: '.ai <your question>',
  async handler(sock, message, args, context = {}) {
    const chatId = context.chatId || message.key.remoteJid;
    const prompt = args.join(' ').trim();

    if (!prompt) {
      return await sock.sendMessage(chatId, {
        text: '👋 *Hello! I am your AI assistant.*\n\nHow can I help you today?\n\nUsage: .ai <your question>'
      }, { quoted: message });
    }

    try {
      const apiKey = 'dew_v0jETv30hOEBwWavO1mSyaN9gyWpTLj4hur2BlDK';
      const url = `https://api.srihub.store/ai/copilot?prompt=${encodeURIComponent(prompt)}&apikey=${apiKey}`;
      
      console.log('Requesting Copilot AI:', url.replace(apiKey, 'REDACTED'));
      
      const [response] = await Promise.all([
        axios.get(url, { timeout: 30000 }),
        sock.sendPresenceUpdate('composing', chatId)
      ]);

      console.log('AI Response:', JSON.stringify(response.data));

      // The API returns { "status": true, "result": "..." }
      if (response.data && response.data.result) {
        await sock.sendMessage(chatId, {
          text: response.data.result
        }, { quoted: message });
      } else {
        throw new Error('Invalid response format from AI server');
      }

    } catch (error) {
      console.error('AI Command Error:', error);
      await sock.sendMessage(chatId, {
        text: `❌ *AI is currently unavailable.*\n\n*Error:* ${error.message}`
      }, { quoted: message });
    }
  }
};
