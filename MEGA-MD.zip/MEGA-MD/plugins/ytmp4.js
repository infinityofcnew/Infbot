const axios = require('axios');
const yts = require('yt-search');

module.exports = {
  command: 'ytmp4',
  aliases: ['ytvideo', 'ytv'],
  category: 'download',
  description: 'Download YouTube video as MP4',
  usage: '.ytmp4 <youtube link | search query>',

  async handler(sock, message, args, context = {}) {
    const chatId = context.chatId || message.key.remoteJid;
    const query = args.join(' ').trim();

    if (!query) {
      return await sock.sendMessage(chatId, {
        text: '🎥 *What video do you want to download?*\n\nUsage: .ytmp4 <youtube link | search query>'
      }, { quoted: message });
    }

    try {
      const [search] = await Promise.all([
        (!query.includes('youtube.com') && !query.includes('youtu.be')) ? yts(query) : Promise.resolve(null),
        sock.sendPresenceUpdate('composing', chatId)
      ]);

      let videoUrl = query;
      if (search) {
        if (!search.all || search.all.length === 0) {
          return await sock.sendMessage(chatId, { text: '❌ No videos found!' }, { quoted: message });
        }
        videoUrl = search.all[0].url;
      }

      // Using the most stable API for fast downloading
      const apiUrl = `https://api.qasimdev.dpdns.org/api/downloader/ytmp4?url=${encodeURIComponent(videoUrl)}&apiKey=qasim-dev`;
      
      const [response] = await Promise.all([
        axios.get(apiUrl, { timeout: 45000 }).catch(() => null),
        sock.sendPresenceUpdate('recording', chatId)
      ]);
      
      let downloadUrl, title, thumbnail, quality, size;

      if (response && response.data && response.data.success && response.data.data?.downloadUrl) {
        ({ title, downloadUrl, thumbnail, quality, size } = response.data.data);
      } else {
        // Fallback API: LoaderTo
        const fallbackUrl = `https://api.qasimdev.dpdns.org/api/loaderto/download?apiKey=qasim-dev&format=360&url=${encodeURIComponent(videoUrl)}`;
        const fbRes = await axios.get(fallbackUrl, { timeout: 45000 });
        if (fbRes.data && fbRes.data.success && fbRes.data.data?.downloadUrl) {
          ({ title, downloadUrl, thumbnail, quality, size } = fbRes.data.data);
        } else {
          throw new Error('All download servers are busy. Please try again.');
        }
      }

      await sock.sendMessage(chatId, {
        video: { url: downloadUrl },
        caption: `🎬 *Title:* ${title}\n🎚️ *Quality:* 360p (Compressed)\n⚖️ *Size:* ${size || 'Compressed'}\n\n> 💫 *INFINITY MD BOT*`,
        mimetype: 'video/mp4',
        fileName: `${title}.mp4`,
        thumbnail: thumbnail ? { url: thumbnail } : null
      }, { quoted: message });

    } catch (error) {
      console.error('YTMP4 Error:', error);
      await sock.sendMessage(chatId, {
        text: `❌ *Download failed!*\n\n*Error:* ${error.message}\n\n💡 Try again or use another link.`
      }, { quoted: message });
    }
  }
};
