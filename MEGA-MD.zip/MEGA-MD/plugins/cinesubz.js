const axios = require('axios');

// Store results temporarily for selection
const searchCache = new Map();

module.exports = {
  command: 'cinesubz',
  aliases: ['movie', 'cs', 'dl'],
  category: 'search',
  description: 'Search and download movies from CineSubz',
  usage: '.cinesubz <movie name> or .dl <number>',
  async handler(sock, message, args, context = {}) {
    const chatId = context.chatId || message.key.remoteJid;
    const input = args.join(' ').trim();
    const apiKey = 'dew_v0jETv30hOEBwWavO1mSyaN9gyWpTLj4hur2BlDK';

    // Handle .dl <number> OR numeric reply to previous search
    const isDlCommand = context.rawText?.toLowerCase().startsWith('.dl');
    const isReply = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    
    if ((isReply && !isNaN(input)) || (isDlCommand && !isNaN(input))) {
      const cache = searchCache.get(chatId);
      if (!cache) {
        return await sock.sendMessage(chatId, { text: '❌ No active search found. Please search for a movie first.' }, { quoted: message });
      }
      
      const index = parseInt(input) - 1;
      if (index < 0 || index >= cache.length) {
        return await sock.sendMessage(chatId, { text: '❌ Invalid selection number.' }, { quoted: message });
      }

      const movie = cache[index];
      try {
        await sock.sendPresenceUpdate('recording', chatId);
        const dlUrl = `https://api.srihub.store/movie/cinesubzdl?url=${encodeURIComponent(movie.link)}&apikey=${apiKey}`;
        const dlRes = await axios.get(dlUrl, { timeout: 60000 });
        
        const resData = dlRes.data?.data || dlRes.data?.result || dlRes.data;
        
        if (resData && resData.download_links && resData.download_links.length > 0) {
          let dlText = `🎬 *${movie.title}*\n\n✅ *Download Links Found:*\n\n`;
          resData.download_links.forEach((link, i) => {
            dlText += `*${i + 1}.* ${link.quality || 'Link'} (${link.size || 'N/A'})\n🔗 ${link.link}\n\n`;
          });
          dlText += `> 💫 *INFINITY MD BOT*`;
          return await sock.sendMessage(chatId, { text: dlText }, { quoted: message });
        } else if (resData && resData.url) {
          return await sock.sendMessage(chatId, { text: `🎬 *${movie.title}*\n\n🔗 *Download Link:* ${resData.url}` }, { quoted: message });
        } else if (typeof resData === 'string' && resData.startsWith('http')) {
          return await sock.sendMessage(chatId, { text: `🎬 *${movie.title}*\n\n🔗 *Download Link:* ${resData}` }, { quoted: message });
        } else if (Array.isArray(resData) && resData.length > 0) {
          let dlText = `🎬 *${movie.title}*\n\n✅ *Download Links Found:*\n\n`;
          resData.forEach((link, i) => {
            const l = typeof link === 'string' ? link : link.link || link.url;
            dlText += `*${i + 1}.* Download Link\n🔗 ${l}\n\n`;
          });
          return await sock.sendMessage(chatId, { text: dlText }, { quoted: message });
        }
        throw new Error('No download links found in the server response.');
      } catch (e) {
        return await sock.sendMessage(chatId, { text: `❌ *Download Error:* ${e.message}` }, { quoted: message });
      }
    }

    if (!input || isDlCommand) {
      if (isDlCommand && !input) {
        return await sock.sendMessage(chatId, { text: 'ℹ️ Usage: .dl <number> (after searching)' }, { quoted: message });
      }
      return await sock.sendMessage(chatId, {
        text: '🔍 *Which movie do you want to search for?*\n\nUsage: .cinesubz <movie name>'
      }, { quoted: message });
    }

    try {
      const url = `https://api.srihub.store/movie/cinesubz?q=${encodeURIComponent(input)}&apikey=${apiKey}`;
      
      const [response] = await Promise.all([
        axios.get(url, { timeout: 30000 }),
        sock.sendPresenceUpdate('composing', chatId)
      ]);

      const results = response.data?.data || response.data?.result;

      if (results && results.length > 0) {
        searchCache.set(chatId, results);
        let text = `╭───〔 🎬 *CINESUBZ SEARCH* 〕───\n│\n`;
        text += `│ 🔍 *Query:* ${input}\n`;
        text += `│ 📊 *Found:* ${results.length} results\n│\n`;
        
        results.forEach((movie, index) => {
          text += `│ *${index + 1}.* ${movie.title}\n`;
        });
        
        text += `│\n╰───────────────────\n\n🔢 *Reply with the number* to get download links.`;

        await sock.sendMessage(chatId, { text }, { quoted: message });
      } else {
        await sock.sendMessage(chatId, {
          text: `❌ *No results found for:* ${input}`
        }, { quoted: message });
      }

    } catch (error) {
      console.error('CineSubz Error:', error);
      await sock.sendMessage(chatId, {
        text: `❌ *Search failed!*\n\n*Error:* ${error.message}`
      }, { quoted: message });
    }
  }
};
